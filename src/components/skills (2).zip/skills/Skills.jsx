import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { portfolio } from "../data/portfolio";
import SectionTitle from "../ui/SectionTitle";
import "./Skills.css";

const panelVariants = {
  hidden: {
    opacity: 0,
    x: 40,
  },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: .45,
      staggerChildren: .08,
    },
  },
  exit: {
    opacity: 0,
    x: -40,
    transition: {
      duration: .25,
    },
  },
};

const chipVariants = {
  hidden: {
    opacity: 0,
    y: 20,
    scale: .9,
  },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
  },
};

const Skills = () => {
  const [active, setActive] = useState(0);

  const current = portfolio.skills[active];

  return (
    <section
      className="skills"
      id="skills"
    >
      <div className="skills-container">

        <SectionTitle
          subtitle="Knowledge Database"
          title="Skills"
        />

        <motion.p
          className="skills-description"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: .8 }}
        >
          Every technology below has been battle-tested through
          real projects, automation frameworks, scalable backend
          systems, and modern frontend development.
        </motion.p>

        <div className="skills-layout">

          {/* LEFT PANEL */}

          <motion.aside
            className="skills-sidebar"
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >

            <div className="sidebar-header">
              <div className="radar" />
              <span>Modules</span>
            </div>

            {portfolio.skills.map((cat, index) => (
              <button
                key={cat.category}
                className={`category-btn ${
                  active === index
                    ? "active"
                    : ""
                }`}
                onClick={() => setActive(index)}
              >
                <span className="category-index">
                  {String(index + 1).padStart(2, "0")}
                </span>

                <span className="category-name">
                  {cat.category}
                </span>

                <span className="category-dot" />
              </button>
            ))}

          </motion.aside>

          {/* RIGHT PANEL */}

          <div className="skills-content">

            <AnimatePresence mode="wait">

              <motion.div
                key={current.category}
                className="skills-panel"
                variants={panelVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
              >

                <div className="panel-header">

                  <div>

                    <p className="panel-subtitle">
                      ACTIVE MODULE
                    </p>

                    <h3>
                      {current.category}
                    </h3>

                  </div>

                  <div className="panel-count">

                    <span>
                      {current.items.length}
                    </span>

                    Skills

                  </div>

                </div>

                <div className="scanner-line" />

                <div className="skills-grid">

                  {current.items.map((skill) => (

                    <motion.div
                      key={skill}
                      variants={chipVariants}
                      className="skill-card"
                    >

                      <div className="skill-orbit" />

                      <div className="skill-glow" />

                      <div className="skill-top">

                        <div className="skill-core" />

                        <span className="skill-status">
                          ONLINE
                        </span>

                      </div>

                      <h4>
                        {skill}
                      </h4>

                      <p>
                        Production Ready
                      </p>

                      <div className="scan" />

                    </motion.div>

                  ))}

                </div>

              </motion.div>

            </AnimatePresence>

          </div>

        </div>

      </div>
    </section>
  );
};

export default Skills;