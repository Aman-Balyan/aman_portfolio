import { useState, useEffect, useRef } from "react";
import "./Skills.css";

const ZONES = [
  {
    id: "languages",
    label: "Languages",
    color: "#6d8eff",
    skills: [
      { name: "Java",   depth: 1   },
      { name: "Python", depth: 0.7 },
      { name: "SQL",    depth: 0.6 },
      { name: "Bash",   depth: 0.45 },
    ],
  },
  {
    id: "frameworks",
    label: "Frameworks",
    color: "#a855f7",
    skills: [
      { name: "Spring Boot",     depth: 1    },
      { name: "Spring MVC",      depth: 0.65 },
      { name: "Spring Security", depth: 0.6  },
      { name: "Hibernate/JPA",   depth: 0.55 },
      { name: "React.js",        depth: 0.75 },
      { name: "REST Assured",    depth: 0.45 },
    ],
  },
  {
    id: "cloud",
    label: "Cloud & DevOps",
    color: "#22d3ee",
    skills: [
      { name: "AWS",     depth: 1    },
      { name: "Docker",  depth: 0.85 },
      { name: "Jenkins", depth: 0.65 },
      { name: "CI/CD",   depth: 0.55 },
    ],
  },
  {
    id: "databases",
    label: "Databases & Messaging",
    color: "#f472b6",
    skills: [
      { name: "MySQL", depth: 1    },
      { name: "Redis", depth: 0.7  },
      { name: "Kafka", depth: 0.65 },
    ],
  },
  {
    id: "testing",
    label: "Testing & Automation",
    color: "#6ee7b7",
    skills: [
      { name: "Selenium",  depth: 1    },
      { name: "TestNG",    depth: 0.65 },
      { name: "Postman",   depth: 0.7  },
      { name: "SonarQube", depth: 0.55 },
    ],
  },
  {
    id: "tools",
    label: "Tools",
    color: "#fbbf24",
    skills: [
      { name: "Git",    depth: 0.9  },
      { name: "GitHub", depth: 0.85 },
      { name: "Maven",  depth: 0.65 },
      { name: "JIRA",   depth: 0.6  },
    ],
  },
  {
    id: "ai",
    label: "Familiar With",
    color: "#c084fc",
    skills: [
      { name: "Generative AI", depth: 0.7  },
      { name: "LLM APIs",      depth: 0.65 },
    ],
  },
];

// ── SINGLE FLOATING WORD ──────────────────────────────────
const SkillWord = ({ name, depth, zoneColor, anyHovered, onHover, onLeave }) => {
  const [hovered, setHovered] = useState(false);
  const anim = useRef({
    x:     (Math.random() - 0.5) * 14,
    y:     (Math.random() - 0.5) * 14,
    dur:   7 + Math.random() * 7,
    delay: -(Math.random() * 10),
  });

  const baseSize  = 0.72 + depth * 1.1;
  const baseAlpha = 0.22 + depth * 0.65;
  const weight    = depth > 0.75 ? 800 : depth > 0.5 ? 600 : 400;
  const isActive  = hovered;
  const isDimmed  = anyHovered && !hovered;

  return (
    <span
      className={`skill-word ${isActive ? "skill-word--active" : ""} ${isDimmed ? "skill-word--dimmed" : ""}`}
      style={{
        "--zone-col":    zoneColor,
        "--base-alpha":  baseAlpha,
        "--fx":          `${anim.current.x}px`,
        "--fy":          `${anim.current.y}px`,
        "--dur":         `${anim.current.dur}s`,
        "--delay":       `${anim.current.delay}s`,
        "--blur":        `${(1 - baseAlpha) * 0.7}px`,
        fontSize:        `${baseSize}rem`,
        fontWeight:      weight,
      }}
      onMouseEnter={() => { setHovered(true);  onHover(); }}
      onMouseLeave={() => { setHovered(false); onLeave(); }}
    >
      {name}
    </span>
  );
};

// ── ZONE CARD ─────────────────────────────────────────────
const ZoneCard = ({ zone, anyHovered, onHover, onLeave }) => {
  const [zoneHov, setZoneHov] = useState(false);

  return (
    <div
      className={`skill-zone ${zoneHov ? "skill-zone--active" : ""} ${anyHovered && !zoneHov ? "skill-zone--dim" : ""}`}
      style={{ "--zone-col": zone.color }}
    >
      {/* top accent line */}
      <div className="zone-accent-line" />

      {/* nebula blob */}
      <div className="zone-nebula" />

      {/* label */}
      <div className="zone-label">
        <span className="zone-dot" style={{ background: zone.color, boxShadow: `0 0 6px ${zone.color}` }} />
        {zone.label}
      </div>

      {/* words */}
      <div className="zone-words">
        {zone.skills.map((s) => (
          <SkillWord
            key={s.name}
            name={s.name}
            depth={s.depth}
            zoneColor={zone.color}
            anyHovered={anyHovered}
            onHover={() => { setZoneHov(true);  onHover(); }}
            onLeave={() => { setZoneHov(false); onLeave(); }}
          />
        ))}
      </div>
    </div>
  );
};

// ── MAIN ─────────────────────────────────────────────────
const Skills = () => {
  const [inView,      setInView]      = useState(false);
  const [anyHovered,  setAnyHovered]  = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setInView(true); },
      { threshold: 0.08 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section className="skills" id="skills" ref={ref}>
      <div className="skills-container">

        <div className={`skills-label ${inView ? "vis" : ""}`}>
          <span className="skills-label-dot" />
          Technical Skills
        </div>

        <h2 className={`skills-headline ${inView ? "vis" : ""}`}>
          The Stack I Ship With
        </h2>

        <p className={`skills-sub ${inView ? "vis" : ""}`}>
          Hover any skill to bring it forward
        </p>

        <div className={`skills-grid ${inView ? "vis" : ""}`}>
          {ZONES.map((zone, i) => (
            <ZoneCard
              key={zone.id}
              zone={zone}
              anyHovered={anyHovered}
              onHover={() => setAnyHovered(true)}
              onLeave={() => setAnyHovered(false)}
            />
          ))}
        </div>

      </div>
    </section>
  );
};

export default Skills;