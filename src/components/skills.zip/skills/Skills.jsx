import { useState } from "react";
import { motion } from "framer-motion";
import { portfolio } from "../data/portfolio";
import SectionTitle from "../ui/SectionTitle";
import "./Skills.css";

const fadeUp = (delay = 0) => ({
  initial:     { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0  },
  viewport:    { once: true },
  transition:  { duration: 0.55, ease: [0.22, 1, 0.36, 1], delay },
});

const Skills = () => {
  const [active, setActive] = useState(0);
  const current = portfolio.skills[active];

  return (
    <section className="skills" id="skills">
      <div className="skills-container">

        <SectionTitle subtitle="What I work with" title="Skills" />

        <div className="skills-layout">

          {/* category tabs — left */}
          <motion.div className="skills-tabs" {...fadeUp(0)}>
            {portfolio.skills.map((cat, i) => (
              <button
                key={i}
                className={`skills-tab ${active === i ? "skills-tab--active" : ""}`}
                onClick={() => setActive(i)}
              >
                <span className="skills-tab-num">
                  {String(i + 1).padStart(2, "0")}
                </span>
                {cat.category}
              </button>
            ))}
          </motion.div>

          {/* items panel — right */}
          <motion.div
            className="skills-panel"
            key={active}
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0  }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            <div className="skills-panel-header">
              <span className="skills-panel-title">{current.category}</span>
              <span className="skills-panel-count">{current.items.length} skills</span>
            </div>
            <div className="skills-items">
              {current.items.map((item, i) => (
                <motion.div
                  key={item}
                  className="skill-item"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0  }}
                  transition={{ delay: i * 0.06, duration: 0.4 }}
                >
                  <span className="skill-item-dot" />
                  {item}
                </motion.div>
              ))}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Skills;