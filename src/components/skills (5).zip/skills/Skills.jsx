import { useEffect, useRef, useState } from "react";
import "./Skills.css";

// ── ALL SKILLS ────────────────────────────────────────────
const SKILLS = [
  { name: "Java",            color: "#f89820", size: 1.6  },
  { name: "Spring Boot",     color: "#6db33f", size: 1.5  },
  { name: "AWS",             color: "#ff9900", size: 1.45 },
  { name: "Selenium",        color: "#43b02a", size: 1.35 },
  { name: "React.js",        color: "#61dafb", size: 1.3  },
  { name: "Docker",          color: "#2496ed", size: 1.3  },
  { name: "Python",          color: "#3776ab", size: 1.2  },
  { name: "Spring Security", color: "#6db33f", size: 1.05 },
  { name: "MySQL",           color: "#4479a1", size: 1.1  },
  { name: "Jenkins",         color: "#d33833", size: 1.0  },
  { name: "Kafka",           color: "#a855f7", size: 1.0  },
  { name: "Redis",           color: "#dc382d", size: 1.0  },
  { name: "Hibernate",       color: "#bcae79", size: 0.95 },
  { name: "Spring MVC",      color: "#6db33f", size: 0.95 },
  { name: "Git",             color: "#f05032", size: 0.95 },
  { name: "Postman",         color: "#ff6c37", size: 0.9  },
  { name: "TestNG",          color: "#ea5c2b", size: 0.88 },
  { name: "Maven",           color: "#c71a36", size: 0.85 },
  { name: "SonarQube",       color: "#4e9bcd", size: 0.82 },
  { name: "JIRA",            color: "#0052cc", size: 0.82 },
  { name: "SQL",             color: "#336791", size: 0.85 },
  { name: "Bash",            color: "#4eaa25", size: 0.8  },
  { name: "GitHub",          color: "#ffffff", size: 0.88 },
  { name: "LLM APIs",        color: "#c084fc", size: 0.78 },
  { name: "Generative AI",   color: "#c084fc", size: 0.82 },
  { name: "REST Assured",    color: "#6db33f", size: 0.8  },
  { name: "CI/CD",           color: "#22d3ee", size: 0.85 },
];

// ── SUPERNOVA CANVAS ──────────────────────────────────────
const SupernovaCanvas = () => {
  const canvasRef  = useRef(null);
  const stateRef   = useRef("idle"); // idle → exploding → floating
  const nodesRef   = useRef([]);
  const particlesRef = useRef([]);
  const mouseRef   = useRef({ x: -9999, y: -9999 });
  const rafRef     = useRef(null);
  const hoveredRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let W, H, CX, CY;

    const resize = () => {
      W  = canvas.width  = canvas.offsetWidth;
      H  = canvas.height = canvas.offsetHeight;
      CX = W / 2;
      CY = H / 2;
    };

    // ── init nodes at center (pre-explosion) ──
    const initNodes = () => {
      nodesRef.current = SKILLS.map((skill, i) => {
        // final resting position — scattered organically
        const angle  = (i / SKILLS.length) * Math.PI * 2 + Math.random() * 0.8;
        const radius = 80 + Math.random() * (Math.min(W, H) * 0.38);
        const tx     = CX + Math.cos(angle) * radius;
        const ty     = CY + Math.sin(angle) * radius;

        return {
          ...skill,
          // start at center
          x: CX, y: CY,
          // target (final) position
          tx, ty,
          // velocity
          vx: 0, vy: 0,
          // explosion direction
          angle,
          // float animation
          phase:    Math.random() * Math.PI * 2,
          floatAmp: 4 + Math.random() * 6,
          floatSpd: 0.4 + Math.random() * 0.4,
          // state
          exploded: false,
          settled:  false,
          alpha:    0,
          scale:    0,
          // hover
          hoverScale: 1,
          pulse: 0,
        };
      });
    };

    // ── spawn supernova particles ──
    const spawnParticles = () => {
      particlesRef.current = [];
      for (let i = 0; i < 120; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 3 + Math.random() * 12;
        particlesRef.current.push({
          x: CX, y: CY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          r:  1 + Math.random() * 3,
          alpha: 1,
          color: ["#6d8eff","#a855f7","#22d3ee","#f89820","#ffffff"][
            Math.floor(Math.random() * 5)
          ],
        });
      }
    };

    // ── trigger explosion ──
    let explodeTimer = null;
    const triggerExplosion = () => {
      if (stateRef.current !== "idle") return;
      stateRef.current = "exploding";
      spawnParticles();

      // stagger nodes flying out
      nodesRef.current.forEach((n, i) => {
        explodeTimer = setTimeout(() => {
          n.exploded = true;
          const speed = 18 + Math.random() * 14;
          n.vx = Math.cos(n.angle) * speed;
          n.vy = Math.sin(n.angle) * speed;
          n.alpha = 1;
          n.scale = 0.4 + Math.random() * 0.4;
        }, i * 35);
      });

      setTimeout(() => {
        stateRef.current = "floating";
      }, SKILLS.length * 35 + 800);
    };

    // ── draw shockwave ring ──
    let shockwave = null;
    const triggerShockwave = () => {
      shockwave = { r: 0, alpha: 1 };
    };

    // ── main render loop ──
    let t = 0;
    let flashAlpha = 0;
    let shockTriggered = false;

    const tick = () => {
      ctx.clearRect(0, 0, W, H);
      t += 0.016;

      // ── CENTER FLASH ──
      if (stateRef.current === "exploding" && flashAlpha < 1.2) {
        flashAlpha += 0.12;
        if (!shockTriggered && flashAlpha >= 0.8) {
          shockTriggered = true;
          triggerShockwave();
        }
      } else if (flashAlpha > 0) {
        flashAlpha -= 0.04;
      }

      if (flashAlpha > 0) {
        const fg = ctx.createRadialGradient(CX, CY, 0, CX, CY, 120 * flashAlpha);
        fg.addColorStop(0, `rgba(255,255,255,${Math.min(flashAlpha, 1)})`);
        fg.addColorStop(0.3, `rgba(109,142,255,${Math.min(flashAlpha * 0.7, 0.7)})`);
        fg.addColorStop(1, "transparent");
        ctx.fillStyle = fg;
        ctx.beginPath();
        ctx.arc(CX, CY, 120 * Math.max(flashAlpha, 0.1), 0, Math.PI * 2);
        ctx.fill();
      }

      // ── SHOCKWAVE ──
      if (shockwave) {
        shockwave.r     += 14;
        shockwave.alpha -= 0.025;
        if (shockwave.alpha > 0) {
          ctx.beginPath();
          ctx.arc(CX, CY, shockwave.r, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(109,142,255,${shockwave.alpha})`;
          ctx.lineWidth   = 2;
          ctx.stroke();

          // second ring slightly behind
          ctx.beginPath();
          ctx.arc(CX, CY, shockwave.r * 0.75, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(168,85,247,${shockwave.alpha * 0.5})`;
          ctx.lineWidth   = 1;
          ctx.stroke();
        } else {
          shockwave = null;
        }
      }

      // ── PARTICLES ──
      particlesRef.current.forEach((p, i) => {
        p.x     += p.vx;
        p.y     += p.vy;
        p.vx    *= 0.96;
        p.vy    *= 0.96;
        p.alpha -= 0.018;
        if (p.alpha > 0) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = p.color + Math.round(p.alpha * 255).toString(16).padStart(2, "0");
          ctx.fill();
        }
      });

      // ── NODES ──
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;
      let closestDist = 60;
      let closestNode = null;

      // sort back to front for drawing
      const sorted = [...nodesRef.current].sort((a, b) => a.scale - b.scale);

      sorted.forEach((n) => {
        if (!n.exploded) return;

        if (stateRef.current === "exploding" || stateRef.current === "floating") {
          // spring toward target
          const dx = n.tx - n.x;
          const dy = n.ty - n.y;
          n.vx += dx * 0.045;
          n.vy += dy * 0.045;
          n.vx *= 0.82;
          n.vy *= 0.82;

          // settle scale
          n.scale += (1 - n.scale) * 0.06;

          // once settled — add float
          if (stateRef.current === "floating") {
            n.x += Math.sin(t * n.floatSpd + n.phase) * 0.18;
            n.y += Math.cos(t * n.floatSpd * 0.7 + n.phase) * 0.14;
          }
        }

        n.x += n.vx;
        n.y += n.vy;

        // mouse gravity
        if (stateRef.current === "floating") {
          const mdx  = mx - n.x;
          const mdy  = my - n.y;
          const mdist = Math.hypot(mdx, mdy);
          if (mdist < 150 && mdist > 50) {
            n.vx += (mdx / mdist) * 0.3;
            n.vy += (mdy / mdist) * 0.3;
          }
          if (mdist < closestDist) {
            closestDist = mdist;
            closestNode = n;
          }
        }

        // draw glow
        const fs = n.size * n.scale * (n === hoveredRef.current ? 1.35 : 1);
        const glowSize = fs * 28;

        if (n === hoveredRef.current) {
          const grd = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, glowSize);
          grd.addColorStop(0, n.color + "55");
          grd.addColorStop(1, "transparent");
          ctx.fillStyle = grd;
          ctx.beginPath();
          ctx.arc(n.x, n.y, glowSize, 0, Math.PI * 2);
          ctx.fill();

          // pulse ring
          n.pulse = (n.pulse || 0) + 0.03;
          const pr = fs * 18 * (1 + Math.sin(n.pulse) * 0.3);
          ctx.beginPath();
          ctx.arc(n.x, n.y, pr, 0, Math.PI * 2);
          ctx.strokeStyle = n.color + "44";
          ctx.lineWidth   = 1;
          ctx.stroke();
        }

        // draw text
        const fontSize = fs * 14;
        ctx.globalAlpha  = n.alpha * (n === hoveredRef.current ? 1 : 0.82);
        ctx.font         = `${n === hoveredRef.current ? 800 : 600} ${fontSize}px "Syne", sans-serif`;
        ctx.textAlign    = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle    = n === hoveredRef.current
          ? n.color
          : `rgba(210,225,255,0.85)`;

        if (n === hoveredRef.current) {
          ctx.shadowColor = n.color;
          ctx.shadowBlur  = 20;
        }

        ctx.fillText(n.name, n.x, n.y);
        ctx.shadowBlur  = 0;
        ctx.globalAlpha = 1;
      });

      hoveredRef.current = closestNode;
      rafRef.current = requestAnimationFrame(tick);
    };

    // ── mouse tracking ──
    const onMove = (e) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };
    const onLeave = () => { mouseRef.current = { x: -9999, y: -9999 }; };
    const onTouch = (e) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
    };

    canvas.addEventListener("mousemove",  onMove);
    canvas.addEventListener("mouseleave", onLeave);
    canvas.addEventListener("touchmove",  onTouch, { passive: true });
    canvas.addEventListener("touchend",   onLeave);

    resize();
    initNodes();
    tick();

    // expose trigger to parent
    canvas._triggerExplosion = triggerExplosion;

    const ro = new ResizeObserver(() => { resize(); initNodes(); });
    ro.observe(canvas.parentElement);

    return () => {
      cancelAnimationFrame(rafRef.current);
      clearTimeout(explodeTimer);
      ro.disconnect();
      canvas.removeEventListener("mousemove",  onMove);
      canvas.removeEventListener("mouseleave", onLeave);
      canvas.removeEventListener("touchmove",  onTouch);
      canvas.removeEventListener("touchend",   onLeave);
    };
  }, []);

  return (
    <div className="supernova-wrap">
      <canvas ref={canvasRef} className="supernova-canvas" />
      <p className="supernova-hint">move cursor to attract skills</p>
    </div>
  );
};

// ── MAIN ─────────────────────────────────────────────────
const Skills = () => {
  const [inView, setInView] = useState(false);
  const canvasRef = useRef(null);
  const ref       = useRef(null);
  const triggered = useRef(false);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setInView(true);
          if (!triggered.current) {
            triggered.current = true;
            // small delay so canvas is visible first
            setTimeout(() => {
              const canvas = ref.current?.querySelector(".supernova-canvas");
              if (canvas?._triggerExplosion) canvas._triggerExplosion();
            }, 400);
          }
        }
      },
      { threshold: 0.2 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section className="skills" id="skills" ref={ref}>
      <div className="skills-container">

        <div className={`skills-label ${inView ? "vis" : ""}`}>
          <span className="skills-label-dot" />
          Technical Skills
        </div>

        <h2 className={`skills-headline ${inView ? "vis" : ""}`}>
          The Stack I Ship With
        </h2>

        <div className={`supernova-section ${inView ? "vis" : ""}`}>
          <SupernovaCanvas />
        </div>

      </div>
    </section>
  );
};

export default Skills;