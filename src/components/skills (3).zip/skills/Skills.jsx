import { useEffect, useRef, useState } from "react";
import "./Skills.css";

// ── SKILL ZONES ───────────────────────────────────────────
const ZONES = [
  {
    id: "languages",
    label: "Languages",
    color: "#6d8eff",
    skills: [
      { name: "Java",   depth: 1   },
      { name: "Python", depth: 0.7 },
      { name: "SQL",    depth: 0.5 },
      { name: "Bash",   depth: 0.4 },
    ],
  },
  {
    id: "frameworks",
    label: "Frameworks",
    color: "#a855f7",
    skills: [
      { name: "Spring Boot",    depth: 1   },
      { name: "Spring MVC",     depth: 0.6 },
      { name: "Spring Security",depth: 0.5 },
      { name: "React",          depth: 0.8 },
      { name: "Hibernate",      depth: 0.4 },
    ],
  },
  {
    id: "cloud",
    label: "Cloud & DevOps",
    color: "#22d3ee",
    skills: [
      { name: "AWS",     depth: 1   },
      { name: "Docker",  depth: 0.9 },
      { name: "Jenkins", depth: 0.6 },
      { name: "CI/CD",   depth: 0.5 },
    ],
  },
  {
    id: "testing",
    label: "Testing & Tools",
    color: "#6ee7b7",
    skills: [
      { name: "Selenium",  depth: 1   },
      { name: "TestNG",    depth: 0.6 },
      { name: "Postman",   depth: 0.7 },
      { name: "SonarQube", depth: 0.5 },
      { name: "JIRA",      depth: 0.4 },
      { name: "Git",       depth: 0.8 },
      { name: "MySQL",     depth: 0.7 },
      { name: "Redis",     depth: 0.5 },
      { name: "Kafka",     depth: 0.6 },
    ],
  },
];

// ── SINGLE FLOATING WORD ──────────────────────────────────
const SkillWord = ({ name, depth, zoneColor, zoneActive, anyHovered, onHover, onLeave }) => {
  const [hovered,  setHovered]  = useState(false);
  const [pos,      setPos]      = useState(null);
  const [animVals, setAnimVals] = useState({
    x: (Math.random() - 0.5) * 12,
    y: (Math.random() - 0.5) * 12,
    dur: 6 + Math.random() * 6,
    delay: -(Math.random() * 8),
  });

  // font size driven by depth — deep = big, far = small
  const baseSize  = 0.75 + depth * 1.35;   // rem  0.75 → 2.1
  const baseAlpha = 0.25 + depth * 0.65;   // 0.25 → 0.9

  const isActive  = hovered;
  const isDimmed  = anyHovered && !hovered;

  const handleEnter = () => { setHovered(true);  onHover(); };
  const handleLeave = () => { setHovered(false); onLeave(); };

  return (
    <span
      className={`skill-word ${isActive ? "skill-word--active" : ""} ${isDimmed ? "skill-word--dimmed" : ""}`}
      style={{
        "--zone-col":   zoneColor,
        "--base-alpha": baseAlpha,
        "--float-x":    `${animVals.x}px`,
        "--float-y":    `${animVals.y}px`,
        "--float-dur":  `${animVals.dur}s`,
        "--float-delay":`${animVals.delay}s`,
        fontSize:       `${baseSize}rem`,
        fontWeight:     depth > 0.7 ? 800 : depth > 0.5 ? 600 : 400,
        letterSpacing:  depth > 0.7 ? "-0.5px" : "0px",
      }}
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
    >
      {name}
    </span>
  );
};

// ── ZONE PANEL ────────────────────────────────────────────
const ZonePanel = ({ zone, anyHovered, onHover, onLeave }) => {
  const [zoneHovered, setZoneHovered] = useState(false);

  return (
    <div
      className={`skill-zone ${zoneHovered ? "skill-zone--active" : ""} ${anyHovered && !zoneHovered ? "skill-zone--dimmed" : ""}`}
      style={{ "--zone-col": zone.color }}
    >
      {/* zone label */}
      <div className="zone-label">
        <span className="zone-label-dot" style={{ background: zone.color, boxShadow: `0 0 6px ${zone.color}` }} />
        {zone.label}
      </div>

      {/* floating words */}
      <div className="zone-words">
        {zone.skills.map((skill) => (
          <SkillWord
            key={skill.name}
            name={skill.name}
            depth={skill.depth}
            zoneColor={zone.color}
            zoneActive={zoneHovered}
            anyHovered={anyHovered}
            onHover={() => { onHover(); setZoneHovered(true);  }}
            onLeave={() => { onLeave(); setZoneHovered(false); }}
          />
        ))}
      </div>

      {/* subtle corner accent */}
      <div className="zone-corner" />
    </div>
  );
};

// ── MAIN ─────────────────────────────────────────────────
const Skills = () => {
  const [inView,     setInView]     = useState(false);
  const [anyHovered, setAnyHovered] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setInView(true); },
      { threshold: 0.1 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section className="skills" id="skills" ref={ref}>
      <div className="skills-container">

        {/* label */}
        <div className={`skills-label ${inView ? "visible" : ""}`}>
          <span className="skills-label-dot" />
          Technical Skills
        </div>

        {/* headline */}
        <h2 className={`skills-headline ${inView ? "visible" : ""}`}>
          The Stack I Ship With
        </h2>

        {/* subtitle */}
        <p className={`skills-sub ${inView ? "visible" : ""}`}>
          Hover any skill to bring it forward
        </p>

        {/* zone grid */}
        <div className={`skills-atmosphere ${inView ? "visible" : ""}`}>
          {ZONES.map((zone, i) => (
            <ZonePanel
              key={zone.id}
              zone={zone}
              anyHovered={anyHovered}
              onHover={() => setAnyHovered(true)}
              onLeave={() => setAnyHovered(false)}
            />
          ))}
        </div>

      </div>
    </section>
  );
};

export default Skills;